import React from 'react';
//import './App.css';



class ListaTarefas extends React.Component{
  
  constructor(props){
    super(props);

    this.state = {tarefas: []};
    this.AdicionarTarefa = this.AdicionarTarefa.bind(this);
  }

  AdicionarTarefa(newTarefa) {
    const tarefas = this.state.tarefas;
    
    if(newTarefa !== ""){
      tarefas.push({descricao: newTarefa});
    }

    this.setState({
      tarefas: tarefas
    });
  }

  // EditarTarefa(index) {
  //   // Fazendo uma copia da lista de tarefas existente, atribuindo na cons tarefas, usando slice que indica um novo posicionamento de memoria
  //   const tarefas = this.state.tarefas.slice();
    
  //   if(index !== ""){
  //     //tarefas.splice(index, 1);
  //     console.log(this.descricao);
  //   }

  //   this.setState({
  //     tarefas: tarefas
  //   });
  // }

  EditarTarefa = (event) => {
    console.log(event.target.value);
      // setChannelState({
      //   avatar: 'avatarCUSTOM.png',
      //   name: event.target.value,
      //   description: "Indefinido",
      //   channelId: 1
      // });
  }

  RemoverTarefa(index) {
    // Fazendo uma copia da lista de tarefas existente, atribuindo na cons tarefas, usando slice que indica um novo posicionamento de memoria
    const tarefas = this.state.tarefas.slice();
    
    if(index !== ""){
      tarefas.splice(index, 1);
    }

    this.setState({
      tarefas: tarefas
    });
  }

  render(){
    return(
      <div>
          <form>
            <input id="NovaTarefa" class="form-control form-control-sm" type="text" informe uma nova tarefa=".form-control-sm" placeholder="Informe uma nova tarefa"></input> 
            <button type="button" onClick={() => this.AdicionarTarefa(document.getElementById('NovaTarefa').value)}>Adicionar</button>
          </form>

          <div>
            {
              this.state.tarefas.map((t, index) => {
                return(
                  // boa prática passar o index na div
                  <div key={index}>
                    <div>
                      <input type="checkbox" id="tarefa" name="tarefa" />
                      <label for="tarefa" onChange={this.EditarTarefa} >{t.descricao}</label>
                      <button type="button" class="botaoremover" onClick={() => this.RemoverTarefa(index)}>Remover</button>
                    </div>  
                  </div>
                );
              })
            }
          </div>
      </div>
    );
  } 
 
}

function App() {
  return (
    <div>
      <header className="App-header">
        <div>
          <div className="App">
            <h3>Lista de Tarefas</h3>
          </div>

          <ListaTarefas />

        </div>
      </header>
    </div>
  );
}

export default App;
